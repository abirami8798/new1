package com.example.mentor_on_demand.service;

import org.springframework.data.repository.CrudRepository;

import com.example.mentor_on_demand.model.Technologies;



public interface TechnologyRepository extends CrudRepository<Technologies, Long> {

}
