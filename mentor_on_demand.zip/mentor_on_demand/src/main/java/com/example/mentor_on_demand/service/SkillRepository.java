package com.example.mentor_on_demand.service;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.example.mentor_on_demand.model.Skills;



public interface SkillRepository extends CrudRepository<Skills, Long>{
	@Query(value="Select skills From Skills skills where skills.skillName = :skillName")
	List<Skills> findBySkillName(@Param("skillName") String skillName);

	Skills save(Skills skills);
}
