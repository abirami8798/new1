package com.example.mentor_on_demand.service;

import org.springframework.data.repository.CrudRepository;

import com.example.mentor_on_demand.model.Payments;


public interface PaymentRepository extends CrudRepository<Payments, Long> {

}
