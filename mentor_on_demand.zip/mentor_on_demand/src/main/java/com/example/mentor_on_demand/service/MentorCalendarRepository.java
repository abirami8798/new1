package com.example.mentor_on_demand.service;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.example.mentor_on_demand.model.MentorCalendar;



public interface MentorCalendarRepository extends CrudRepository<MentorCalendar, Long> {

	MentorCalendar findByMentorId(long mentorId);

	

}
