package com.example.mentor_on_demand.service;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.example.mentor_on_demand.model.Trainings;




public interface TrainingRepository  extends CrudRepository<Trainings, Long> {

	Trainings save(Trainings trainings);

	//List<Trainings> findByStatus(String status);


	//List<Trainings> findByUserId(long userId);

	//List<Trainings> findByAmountReceived(String amount);
	
}
